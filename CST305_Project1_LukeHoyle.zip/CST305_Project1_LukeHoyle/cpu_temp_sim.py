"""
CST-305: Project 1 – Visualize ODE with SciPy
Luke Hoyle
Prof. Citro
September 7, 2025

Description:
This program models CPU heat dissipation using an ordinary differential equation (ODE).
It collects user input for the variables like cpu temperautre, enviroment temperature, cooling constant, 
and power input. It then uses a mathmatical formula the ODE to show hot the cpu get too hot so an engineer 
can design liquid cooling or fan cooling system to combat this and make sure it does not overheat. It then 
graphs this for the user to see it vissiually using matplotlib.


Packages Used:
- numpy (for arrays and math operations)
- scipy.integrate (for ODE solver)
- matplotlib.pyplot (for plotting results)

Approach to Implementation:
1. Define the ODE: dT/dt = -k*(T - Tamb) + P
2. Request user inputs for variables.
3. Solve the ODE with solve_ivp.
4. Evaluate the solution at evenly spaced points using NumPy.
5. Plot and label the results with Matplotlib.
"""

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the ODE: dT/dt = -k*(T - Tamb) + P
def cpu_temp(t, T, k, Tamb, P):
    return -k*(T - Tamb) + P

# Get the user input and set the paramaters
k = float(input("Enter cooling constant k: "))
Tamb = float(input("Enter ambient temperature (°C): "))
P = float(input("Enter power input: "))
T0 = float(input("Enter initial CPU temperature (°C): "))
t_max = float(input("Enter simulation time (seconds): "))

# Plugs in the variables and solves the ODE
sol = solve_ivp(cpu_temp, [0, t_max], [T0], args=(k, Tamb, P), dense_output=True)

# This smoothes out the line so it doesn't jump by taking 300 points along the line
t_vals = np.linspace(0, t_max, 300)
T_vals = sol.sol(t_vals)[0]

# Plots the result for the user so they can vissualize it
plt.figure(figsize=(8,5))
plt.plot(t_vals, T_vals, label="CPU Temperature", linewidth=2)
plt.axhline(y=Tamb, color='gray', linestyle='--', label="Ambient Temp")

plt.xlabel("Time (s)")
plt.ylabel("Temperature (°C)")
plt.title("CPU Temperature Simulation using ODE")
plt.legend()
plt.grid(True)
plt.show()
