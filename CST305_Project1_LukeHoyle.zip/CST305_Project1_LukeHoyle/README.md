# Project 1 ODE Simulation

## Overview
This project models CPU heat change using an ODE. It simulates how the temperature of a CPU changes over time given user inputs  and shows the result using Python and SciPy.

The ODE used is:
```
dT/dt = -k * (T - Tamb) + P
```
Where:
- `T` = CPU temperature (°C)  
- `Tamb` = ambient room temperature (°C)  
- `k` = cooling constant (rate of heat removal)  
- `P` = power input (heat generation rate)  

## Requirements
- Python 3.13+
- numpy
- scipy
- matplotlib

## Usage
1. Save the code as `cpu_temp_sim.py`.  
2. Run the program in Command Prompt:
```bash
python cpu_temp_sim.py
```
3. Enter values when prompted:
   - Cooling constant `k`   
   - Ambient temperature (°C)  
   - Power input  
   - Initial CPU temperature (°C)  
   - Simulation time (seconds)  

4. A graph will display showing CPU temperature change over time.

## Example Run
Input:
```
Enter cooling constant k: 0.1
Enter ambient temperature (°C): 25
Enter power input (heat generation rate): 50
Enter initial CPU temperature (°C): 30
Enter simulation time (seconds): 100
```

Output:  
A graph where the CPU temperature rises from 30°C, then evens out.

## Files
- `cpu_temp_sim.py` → Python program  
- `CST305_Project1_LukeHoyle.docx` → Documentation/report  
- `README.md` → Instructions  
- `screenshots/` → Example program execution and plots  

## Author
Luke Hoyle  
Prof. Citro  
CST-305
